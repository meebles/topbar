module.exports = {
  user: 'admin_tom',
  password: 'P1anoman.',
};
