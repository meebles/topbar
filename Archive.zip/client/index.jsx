import React from 'react';
import ReactDOM from 'react-dom';
import SearchModal from './SearchModal';

// eslint-disable-next-line no-undef
ReactDOM.render(<SearchModal />, document.getElementById('t_topbar-root'));
