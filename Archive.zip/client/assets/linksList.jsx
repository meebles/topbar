module.exports = [
  'Wi nøt trei a høliday in Sweden this yër?',
  'See the løveli lakes',
  'And mäni interesting furry animals',
  'Including the majestik møøse',
  'A Møøse once bit my sister...',
];
